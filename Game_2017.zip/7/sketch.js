/*

The Game Project 7

Week 8

*/

var game_char_x;
var game_char_y;
var floorPos_y;
var scrollPos;
var realPos;

var isLeft;
var isRight;
var isJumping;
var isFalling;

var clouds;
var sun;
var backMountain;
var mountain;
var trees;
var buildings;
var houseXs;
var TALLhouseXs;
var house_x;
var house_y;
var canyons;
var jewels;

var score;
var isLost;
var isWon;
var lives;

var enemies;
var tokens;

var platforms;
var isOnPlatform;

function setup() {
    createCanvas(1024, 576);
    score = 0;
    lives = 3;
    floorPos_y = height * 3 / 4;
    startGame();
}

function startGame() {
    game_char_x = width / 3.3;
    game_char_y = floorPos_y;
    // Variable to control the background scrolling.
    
    scrollPos = 0;    

    // Variable to store the real position of the gameChar in the game
    // world. Needed for collision detection.
    realPos = game_char_x - scrollPos;

    // Boolean variables to control the movement of the game character.
    isLeft = false;
    isRight = false;
    isJumping = false;
    isFalling = false;
    
    isLost = false;
    isWon = false;
    
    // Initialise arrays of scenery objects.

    TALLhouseXs = [1100, 1300, 1500, 1700, 1900]
    houseXs = [300, 500, 700, 900]
        
    house_x = random(0, width / 8.5);
    house_y = floorPos_y - 50;
    
    buildings = [];
    for (var i = 0; i < 15; i++) {
        var bd = {
            x_pos: random(50, 2000),
            height: random(220,400),
            width: random(100,160)
        };
        buildings.push(bd);
    }
    
    clouds = [];
    for (var i = 0; i < 50; i++) {
        var c = {
            x_pos: random(0, 8000),
            y_pos: random(50, 80)
        };
        clouds.push(c);
    }

    sun = {
        x_pos: 0,
        y_pos: 0,
        size: 200
    }

    mountain = {
        x_pos: [-50, 350, 750, 1150, 1500],
        height: [100, 100, 100, 100, 100]
    }

    backMountain = [];
    for (var i = 0; i < 50; i++) {
        var bm = {
            x_pos: random(0, 2000),
            height: random(220, 320)
        };
        backMountain.push(bm);
    }
    
    backTree = [];
    for (var i = 0; i < 20; i++) {
        var bt = {
            x_pos: random(0, 2400),
            height: random(160, 250)
        };
        backTree.push(bt);
    }
    
    tree = {
        x_pos: [300, 550, 800, 1050, 1300, 1550, 1800, 2050, 2300],
        height: [floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49, floorPos_y - 49]
    }

    canyons = [
        {x_pos: 600,width: 100},
        {x_pos: 800,width: 200},
        {x_pos: 1200,width: 150},
        {x_pos: 1400,width: 100},
        {x_pos: 1600,width: 150},
        {x_pos: 1800,width: 200}
    ]

    jewels = [
        {x_pos: 750,y_pos: 450,size: 50,isFound: false},
        {x_pos: 955,y_pos: 315,size: 50,isFound: false},
        {x_pos: 1550,y_pos: 450,size: 50,isFound: false},
        {x_pos: 1775,y_pos: 450,size: 50,isFound: false},
        {x_pos: 2400,y_pos: 450,size: 50,isFound: false}
    ]

   tokens = [
        { x_pos: 100, y_pos: 73,} ,
        { x_pos: 130, y_pos: 73, },
        { x_pos: 160, y_pos: 73, }
    ]
	
    enemies = [];
    enemies.push({
        x_pos: 1100,
        y_pos: 450,
        x1: 1020,
        x2: 1180,
        speed: 1,
        size: 30,
        display: function () {
            // Draw enemy.
            stroke(0)
            fill(0, 255, 0);
            ellipse(this.x_pos, this.y_pos-13, this.size);
            fill(0);
            ellipse(this.x_pos-6, this.y_pos-18, this.size-20,this.size-16);
            ellipse(this.x_pos+6, this.y_pos-18, this.size-20,this.size-16);
            fill(255);
            ellipse(this.x_pos-8, this.y_pos-18, this.size-26,this.size-22);
            ellipse(this.x_pos+4, this.y_pos-18, this.size-26,this.size-22);
        },
        move: function () {
            this.x_pos += this.speed;
            if (this.x_pos < this.x1 || this.x_pos > this.x2) {
                this.speed *= -1;
            }
        },
        checkCharCollision: function () {
            if (abs(realPos - this.x_pos) < 20 && abs(game_char_y - this.y_pos) < 20) {
                playerDied();
            }
        }
    });
    
    enemies.push({
        x_pos: 520,
        y_pos: 450,
        x1: 420,
        x2: 590,
        speed: 1,
        size: 30,
        display: function () {
            // Draw enemy.
            fill(200, 80, 180);
            ellipse(this.x_pos, this.y_pos-13, this.size);
            fill(0);
            ellipse(this.x_pos-6, this.y_pos-18, this.size-20,this.size-16);
            ellipse(this.x_pos+6, this.y_pos-18, this.size-20,this.size-16);
            fill(255);
            ellipse(this.x_pos-8, this.y_pos-18, this.size-26,this.size-22);
            ellipse(this.x_pos+4, this.y_pos-18, this.size-26,this.size-22);
        },
        move: function () {
            this.x_pos += this.speed;
            if (this.x_pos < this.x1 || this.x_pos > this.x2) {
                this.speed *= -1;
            }
        },
        checkCharCollision: function () {
            if (abs(realPos - this.x_pos) < 20 && abs(game_char_y - this.y_pos) < 20) {
                playerDied();
            }
        }
    });
    
    enemies.push({
        x_pos: 2150,
        y_pos: 450,
        x1: 2030,
        x2: 2280,
        speed: 1,
        size: 30,
        display: function () {
            // Draw enemy.
            fill(0, 0, 255);
            ellipse(this.x_pos, this.y_pos-13, this.size);
            fill(0);
            ellipse(this.x_pos-6, this.y_pos-18, this.size-20,this.size-16);
            ellipse(this.x_pos+6, this.y_pos-18, this.size-20,this.size-16);
            fill(255);
            ellipse(this.x_pos-8, this.y_pos-18, this.size-26,this.size-22);
            ellipse(this.x_pos+4, this.y_pos-18, this.size-26,this.size-22);
        },
        move: function () {
            this.x_pos += this.speed;
            if (this.x_pos < this.x1 || this.x_pos > this.x2) {
                this.speed *= -1;
            }
        },
        checkCharCollision: function () {
            if (abs(realPos - this.x_pos) < 20 && abs(game_char_y - this.y_pos) < 20) {
                playerDied();
            }
        }
    });
    
    enemies.push({
        x_pos: 750,
        y_pos: 385,
        x1: 700,
        x2: 800,
        speed: 1,
        size: 30,
        display: function () {
            // Draw enemy.
            fill(255, 0, 0);
            ellipse(this.x_pos, this.y_pos-13, this.size);
            fill(0);
            ellipse(this.x_pos-6, this.y_pos-18, this.size-20,this.size-16);
            ellipse(this.x_pos+6, this.y_pos-18, this.size-20,this.size-16);
            fill(255);
            ellipse(this.x_pos-8, this.y_pos-18, this.size-26,this.size-22);
            ellipse(this.x_pos+4, this.y_pos-18, this.size-26,this.size-22);
        },
        move: function () {
            this.x_pos += this.speed;
            if (this.x_pos < this.x1 || this.x_pos > this.x2) {
                this.speed *= -1;
            }
        },
        checkCharCollision: function () {
            if (abs(realPos - this.x_pos) < 20 && abs(game_char_y - this.y_pos) < 20) {
                playerDied();
            }
        }
    });
    
    enemies.push({
        x_pos: -300,
        y_pos: 280,
        x1: 700,
        x2: 800,
        speed: 1,
        size: 30,
        display: function () {
            // Draw enemy.
            fill(51, 25, 0);
            ellipse(this.x_pos, this.y_pos-13, this.size*12);
            fill(0);
            ellipse(this.x_pos-6, this.y_pos-18, this.size-20*6,this.size-16*10);
            ellipse(this.x_pos+90, this.y_pos-18, this.size-20*6,this.size-16*10);
            fill(255);
            ellipse(this.x_pos+13, this.y_pos-10, this.size-26*3,this.size-22*5);
            ellipse(this.x_pos+110, this.y_pos-10, this.size-26*3,this.size-22*5);
        },
        move: function () {
            this.x_pos += this.speed;
            if (this.x_pos < this.x1 || this.x_pos > this.x2) {
                this.speed *= -1;
            }
        },
        checkCharCollision: function () {
            if (abs(realPos - this.x_pos) < 20*7 && abs(game_char_y - this.y_pos) < 20*13) {
                playerDied();
            }
        }
    });
    
    //platforms
    platforms = [];
    platforms.push({
            x_pos: 700,
            y_pos: floorPos_y - 80,
            width: 100,
            height: 15,

            display: function () {

                fill([255, 155, 50]);
                rect(this.x_pos, this.y_pos + 34, this.width, this.height);
                line(this.x_pos, this.y_pos + this.height / 2, this.x_pos + this.width, this.y_pos + this.height / 2);
            },
            checkCharOn: function () {
                if (realPos - this.x_pos < this.width + 25 && realPos - this.x_pos > 0 && abs(game_char_y - this.y_pos) <= 0)

                    isOnPlatform = true;

            }
        }


    )
    platforms.push({
            x_pos: 1100,
            y_pos: floorPos_y - 80,
            width: 100,
            height: 15,

            display: function () {

                fill([255, 155, 50]);
                rect(this.x_pos, this.y_pos + 34, this.width, this.height);
                line(this.x_pos, this.y_pos + this.height / 2, this.x_pos + this.width, this.y_pos + this.height / 2);
            },
            checkCharOn: function () {
                if (realPos - this.x_pos < this.width + 25 && realPos - this.x_pos > 0 && abs(game_char_y - this.y_pos) <= 0)

                    isOnPlatform = true;

            }
        }
    )
    platforms.push({
            x_pos: 900,
            y_pos: floorPos_y - 130,
            width: 100,
            height: 15,

            display: function () {

                fill([255, 155, 50]);
                rect(this.x_pos, this.y_pos + 34, this.width, this.height);
                line(this.x_pos, this.y_pos + this.height / 2, this.x_pos + this.width, this.y_pos + this.height / 2);
            },
            checkCharOn: function () {
                if (realPos - this.x_pos < this.width + 25 && realPos - this.x_pos > 0 && abs(game_char_y - this.y_pos) <= 0)

                    isOnPlatform = true;

            }
        }
    )
};




function draw() {
    background(100, 155, 255); // fill the sky blue

    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, width, height / 4); // draw some green ground

    // Draw mountains.
    push();
    translate(scrollPos * 0.6, 0);
    draw_backMountains();
    pop();

    push();
    translate(scrollPos * 0.6, 0);
    drawMountains();
    pop();
    // Draw buildings.
    push();
    translate(scrollPos * 1.3, 0);
    for (var i = 0; i < buildings.length; i++) {
        drawBuildings(buildings[i]);
    }
    pop();
    // Draw clouds.
    push();
    translate(scrollPos * 0.3, 0);
    drawClouds();
    pop();

    push();
    translate(scrollPos * 0.1, 0);
    drawSun();
    pop();

    // Draw trees.
    push();
    translate(scrollPos * 1.2, 0);
    for (var i = 0; i < backTree.length; i++) {
        draw_backTrees(backTree[i]);
    }
    pop();
    
    push();
    translate(scrollPos * 1.2, 0);
    drawTrees();
    pop();

    // Draw houses.
    push();
    translate(scrollPos * 1, 0);
    drawHouses();
    pop();

    // Draw canyons.
    push();
    translate(scrollPos * 1, 0);
    for (var i = 0; i < canyons.length; i++) {
        drawCanyon(canyons[i]);
        checkCanyon(canyons[i]);
    }
    pop();
    // Draw pickup items.
    push();
    translate(scrollPos * 1, 0);
    for (var i = 0; i < jewels.length; i++) {
        drawPickup(jewels[i]);
        checkPickup(jewels[i]);
    }
    pop();
    
    //draw platforms
    push();
    translate(scrollPos, 0)
    isOnPlatform = false;
    for (var i = 0; i < platforms.length; i++) {
        platforms[i].display();
        platforms[i].checkCharOn();
    }
    pop();
    
    // Draw game character.
    drawGameChar();
		 if(isLost == true) {
             push();
             stroke(0);
             strokeWeight(2);
             textSize(60)
             fill(255,0,0);
             text("GAME OVER!", 380, 300);
             text("Press SPACE to advance!",200,365);
             isLeft = false;
             isRight = false;
             pop();
    }
  
    checkPlayerWon();
    checkPlayerDied();

		// draw the enemies 
	push();
    translate(scrollPos, 0);
	for(var i = 0; i < enemies.length; i++)
		{
			enemies[i].display();	
		    enemies[i].move();
			enemies[i].checkCharCollision();
		}
	 pop();
    
    

    // Logic to make the game character move or the background scroll.
    if (isLeft) {
        if (game_char_x > width * 0.2) {
            game_char_x -= 5;
        } else {
            scrollPos += 5;
        }
    }

    if (isRight) {
        if (game_char_x < width * 0.8) {
            game_char_x += 5;
        } else {
            scrollPos -= 5; // negative for moving against the background
        }
    }

    // Logic to make the game character rise and fall.
    if (game_char_y < floorPos_y && !isOnPlatform) {
        game_char_y += 2;
        isJumping = true;
    } else {
        isJumping = false;
    }

    if (isFalling) {
        game_char_y += 5;
    }

    // Update real position of gameChar for collision detection.
    realPos = game_char_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed() {

    // console.log(keyCode);
    // console.log(key);

    if (key == 'A' || keyCode == 37) {
        isLeft = true;
    }

    if (key == 'D' || keyCode == 39) {
        isRight = true;
    }

    if (key == ' ' || key == 'W') {
        if (!isJumping) {
            game_char_y -= 100;
        }
    }
    
    if(isLost || isWon)
    {
    if(key == ' ')
    {
        
        nextLevel();
    }
    return;
    }
}

function keyReleased() {

    if (key == 'A' || keyCode == 37) {
        isLeft = false;
    }

    if (key == 'D' || keyCode == 39) {
        isRight = false;
    }

}


// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar() {
    // draw game character
    if (isLeft && isJumping) {
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x - 7, game_char_y - 13, game_char_x - 5, game_char_y - 13);
        //eyes
        line(game_char_x - 4, game_char_y - 18, game_char_x - 6, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 1, game_char_y + 23, game_char_x, game_char_y + 15, game_char_x + 3, game_char_y + 10, game_char_x + 6, game_char_y + 22);
        quad(game_char_x - 1, game_char_y + 23, game_char_x, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 6, game_char_y + 22);
        quad(game_char_x, game_char_y + 22, game_char_x + 15, game_char_y + 31, game_char_x + 15, game_char_y + 26, game_char_x + 6, game_char_y + 21);
        quad(game_char_x, game_char_y + 22, game_char_x + 5, game_char_y + 34, game_char_x, game_char_y + 36, game_char_x - 6, game_char_y + 21);
        //arms
        quad(game_char_x, game_char_y - 6, game_char_x - 4, game_char_y - 2, game_char_x - 17, game_char_y - 5, game_char_x - 21, game_char_y - 12);
        quad(game_char_x, game_char_y - 6, game_char_x + 4, game_char_y - 4, game_char_x + 21, game_char_y - 1, game_char_x + 20, game_char_y - 8);
        //cape
        fill(195, 120, 0);
        quad(game_char_x - 5, game_char_y - 8, game_char_x + 5, game_char_y - 8, game_char_x + 24, game_char_y + 10, game_char_x + 14, game_char_y + 13)
    } else if (isRight && isJumping) {
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x + 7, game_char_y - 13, game_char_x + 5, game_char_y - 13);
        //eyes
        line(game_char_x + 4, game_char_y - 18, game_char_x + 6, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 1, game_char_y + 23, game_char_x, game_char_y + 15, game_char_x + 3, game_char_y + 10, game_char_x + 6, game_char_y + 22);
        quad(game_char_x - 1, game_char_y + 23, game_char_x, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 6, game_char_y + 22);
        quad(game_char_x + 1, game_char_y + 27, game_char_x - 15, game_char_y + 30, game_char_x - 15, game_char_y + 26, game_char_x + 6, game_char_y + 22);
        quad(game_char_x - 5, game_char_y + 37, game_char_x, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 9, game_char_y + 35);
        //arms
        quad(game_char_x, game_char_y - 6, game_char_x + 4, game_char_y - 2, game_char_x + 20, game_char_y - 8, game_char_x + 15, game_char_y - 12);
        quad(game_char_x, game_char_y - 6, game_char_x - 4, game_char_y - 2, game_char_x - 20, game_char_y, game_char_x - 15, game_char_y - 5);
        //cape
        fill(195, 120, 0);
        quad(game_char_x - 5, game_char_y - 8, game_char_x + 5, game_char_y - 8, game_char_x - 14, game_char_y + 13, game_char_x - 24, game_char_y + 10)
    } else if (isLeft) {
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x - 7, game_char_y - 13, game_char_x - 5, game_char_y - 13);
        //eyes
        line(game_char_x - 4, game_char_y - 18, game_char_x - 6, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 1, game_char_y + 33, game_char_x, game_char_y + 15, game_char_x + 3, game_char_y + 10, game_char_x + 6, game_char_y + 32);
        quad(game_char_x - 1, game_char_y + 33, game_char_x, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 6, game_char_y + 32);
        //arms
        quad(game_char_x, game_char_y - 6, game_char_x + 4, game_char_y - 6, game_char_x + 10, game_char_y + 12, game_char_x + 5, game_char_y + 12);
        quad(game_char_x, game_char_y - 6, game_char_x - 4, game_char_y - 6, game_char_x - 10, game_char_y + 12, game_char_x - 5, game_char_y + 12);
        //cape
        fill(195, 120, 0);
        quad(game_char_x + 5, game_char_y - 8, game_char_x - 5, game_char_y - 8, game_char_x + 10, game_char_y + 33, game_char_x + 20, game_char_y + 30);
    } else if (isRight) {
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x + 7, game_char_y - 13, game_char_x + 5, game_char_y - 13);
        //eyes
        line(game_char_x + 4, game_char_y - 18, game_char_x + 6, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 1, game_char_y + 33, game_char_x, game_char_y + 15, game_char_x + 3, game_char_y + 10, game_char_x + 6, game_char_y + 32);
        quad(game_char_x - 1, game_char_y + 33, game_char_x, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 6, game_char_y + 32);
        //arms
        quad(game_char_x, game_char_y - 6, game_char_x + 4, game_char_y - 6, game_char_x + 10, game_char_y + 12, game_char_x + 5, game_char_y + 12);
        quad(game_char_x, game_char_y - 6, game_char_x - 4, game_char_y - 6, game_char_x - 10, game_char_y + 12, game_char_x - 5, game_char_y + 12);
        //cape
        fill(195, 120, 0);
        quad(game_char_x - 5, game_char_y - 8, game_char_x + 5, game_char_y - 8, game_char_x - 10, game_char_y + 33, game_char_x - 20, game_char_y + 30)
    } else if (isJumping || isFalling) {
        //cape
        fill(195, 120, 0);
        quad(game_char_x + 5, game_char_y - 10, game_char_x - 5, game_char_y - 10, game_char_x - 20, game_char_y + 10, game_char_x + 20, game_char_y + 10)
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x - 2, game_char_y - 13, game_char_x + 1, game_char_y - 13);
        //eyes
        line(game_char_x - 5, game_char_y - 18, game_char_x - 3, game_char_y - 17);
        line(game_char_x + 4, game_char_y - 18, game_char_x + 2, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 2, game_char_y + 33, game_char_x + 1, game_char_y + 15, game_char_x + 4, game_char_y + 10, game_char_x + 6, game_char_y + 34);
        quad(game_char_x - 3, game_char_y + 33, game_char_x - 1, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 8, game_char_y + 34);
        //arms
        quad(game_char_x + 4, game_char_y - 6, game_char_x + 4, game_char_y, game_char_x + 22, game_char_y - 24, game_char_x + 17, game_char_y - 24);
        quad(game_char_x - 4, game_char_y - 6, game_char_x - 4, game_char_y, game_char_x - 22, game_char_y - 24, game_char_x - 17, game_char_y - 24);
    } else {
        //cape
        fill(195, 120, 0);
        quad(game_char_x + 5, game_char_y - 10, game_char_x - 5, game_char_y - 10, game_char_x - 20, game_char_y + 30, game_char_x + 20, game_char_y + 30)
        //body
        fill(0);
        ellipse(game_char_x, game_char_y, 10, 30);
        //head
        ellipse(game_char_x, game_char_y - 15, 15, 15);
        //straw hat
        fill(195, 120, 0);
        triangle(game_char_x - 20, game_char_y - 22, game_char_x, game_char_y - 39, game_char_x + 20, game_char_y - 20);
        //mouth
        noFill();
        stroke(255);
        line(game_char_x - 2, game_char_y - 13, game_char_x + 1, game_char_y - 13);
        //eyes
        line(game_char_x - 5, game_char_y - 18, game_char_x - 3, game_char_y - 17);
        line(game_char_x + 4, game_char_y - 18, game_char_x + 2, game_char_y - 17);
        //legs
        fill(0);
        noStroke();
        quad(game_char_x + 2, game_char_y + 33, game_char_x + 1, game_char_y + 15, game_char_x + 4, game_char_y + 10, game_char_x + 6, game_char_y + 34);
        quad(game_char_x - 3, game_char_y + 33, game_char_x - 1, game_char_y + 15, game_char_x - 3, game_char_y + 10, game_char_x - 8, game_char_y + 34);
        //arms
        quad(game_char_x + 4, game_char_y - 6, game_char_x + 9, game_char_y - 6, game_char_x + 12, game_char_y + 12, game_char_x + 7, game_char_y + 12);
        quad(game_char_x - 4, game_char_y - 6, game_char_x - 9, game_char_y - 6, game_char_x - 12, game_char_y + 12, game_char_x - 7, game_char_y + 12);
    }
//Draw score
     push();
     stroke(2);
     fill(255,0,0);
     textSize(32);
     text('Score: ' + score, 10,40);
     pop();

     // Draw Lives Label
     push();
     stroke(2);
     fill(255,0,0);
     textSize(24);
     text('Lives: ', 10,80);
	drawTokens();
     pop();
}


// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.
function drawSun() {
    //sun
    fill(245, 235, 90, 100)
    ellipse(sun.x_pos, sun.y_pos, sun.size + 90);
    fill(245, 235, 90, 50)
    ellipse(sun.x_pos, sun.y_pos, sun.size + 70);
    fill(245, 235, 90)
    ellipse(sun.x_pos, sun.y_pos, sun.size + 50);
}

function drawClouds() {
    // Draw clouds.
    for (var i = 0; i < clouds.length; i++) {
        fill(105)
        ellipse(clouds[i].x_pos - 5, clouds[i].y_pos - 30, 105);
        ellipse(clouds[i].x_pos - 65, clouds[i].y_pos - 50, 105);
        ellipse(clouds[i].x_pos + 55, clouds[i].y_pos - 50, 105);
        ellipse(clouds[i].x_pos - 115, clouds[i].y_pos - 60, 105);
        ellipse(clouds[i].x_pos + 105, clouds[i].y_pos - 60, 105);
        ellipse(clouds[i].x_pos - 205, clouds[i].y_pos - 30, 105);
        ellipse(clouds[i].x_pos - 265, clouds[i].y_pos - 50, 105);
        ellipse(clouds[i].x_pos - 155, clouds[i].y_pos - 50, 105);
        ellipse(clouds[i].x_pos - 315, clouds[i].y_pos - 60, 105);
        ellipse(clouds[i].x_pos - 355, clouds[i].y_pos - 65, 105);
        ellipse(clouds[i].x_pos + 215, clouds[i].y_pos - 20, 105);
        ellipse(clouds[i].x_pos + 275, clouds[i].y_pos - 40, 105);
        ellipse(clouds[i].x_pos + 175, clouds[i].y_pos - 40, 105);
        ellipse(clouds[i].x_pos + 325, clouds[i].y_pos - 50, 105);
        ellipse(clouds[i].x_pos + 365, clouds[i].y_pos - 55, 105);
        ellipse(clouds[i].x_pos + 515, clouds[i].y_pos - 10, 105);
        ellipse(clouds[i].x_pos + 475, clouds[i].y_pos - 30, 105);

        fill(245);
        ellipse(clouds[i].x_pos, clouds[i].y_pos - 30, 100);
        ellipse(clouds[i].x_pos - 60, clouds[i].y_pos - 50, 100);
        ellipse(clouds[i].x_pos + 60, clouds[i].y_pos - 50, 100);
        ellipse(clouds[i].x_pos - 110, clouds[i].y_pos - 60, 100);
        ellipse(clouds[i].x_pos + 110, clouds[i].y_pos - 60, 100);
        ellipse(clouds[i].x_pos - 200, clouds[i].y_pos - 30, 100);
        ellipse(clouds[i].x_pos - 260, clouds[i].y_pos - 50, 100);
        ellipse(clouds[i].x_pos - 160, clouds[i].y_pos - 50, 100);
        ellipse(clouds[i].x_pos - 310, clouds[i].y_pos - 60, 100);
        ellipse(clouds[i].x_pos - 350, clouds[i].y_pos - 65, 105);
        ellipse(clouds[i].x_pos + 220, clouds[i].y_pos - 20, 100);
        ellipse(clouds[i].x_pos + 280, clouds[i].y_pos - 40, 100);
        ellipse(clouds[i].x_pos + 180, clouds[i].y_pos - 40, 100);
        ellipse(clouds[i].x_pos + 330, clouds[i].y_pos - 50, 100);
        ellipse(clouds[i].x_pos + 380, clouds[i].y_pos - 55, 105);
        ellipse(clouds[i].x_pos + 520, clouds[i].y_pos - 10, 100);
        ellipse(clouds[i].x_pos + 480, clouds[i].y_pos - 30, 100);
        rect(clouds[i].x_pos, clouds[i].y_pos - 50, 1025, 30);
    }
}
// Function to draw mountains objects.
function drawMountains() {
    //MOUNTAIN ------------------------------------------------------------------------------
    for (var i = 0; i < mountain.x_pos.length; i++) {
        fill(30, 30, 60)
        quad(mountain.x_pos[i] + 90, mountain.height[i] + 333, mountain.x_pos[i] + 390, mountain.height[i] + 333, mountain.x_pos[i] + 320, mountain.height[i] + 200, mountain.x_pos[i] + 190, mountain.height[i] + 200);
        quad(mountain.x_pos[i] - 30, mountain.height[i] + 333, mountain.x_pos[i] + 90, mountain.height[i] + 333, mountain.x_pos[i] + 190, mountain.height[i] + 200, mountain.x_pos[i] + 210, mountain.height[i] - 10);
        quad(mountain.x_pos[i] - 10, mountain.height[i] + 305, mountain.x_pos[i] + 10, mountain.height[i] + 200, mountain.x_pos[i] + 80, mountain.height[i] + 100, mountain.x_pos[i] + 105, mountain.height[i] + 140);
        quad(mountain.x_pos[i] + 190, mountain.height[i] + 200, mountain.x_pos[i] + 320, mountain.height[i] + 200, mountain.x_pos[i] + 280, mountain.height[i] + 100, mountain.x_pos[i] + 210, mountain.height[i] - 10);
        fill(30, 30, 120);
        quad(mountain.x_pos[i] + 390, mountain.height[i] + 333, mountain.x_pos[i] + 320, mountain.height[i] + 200, mountain.x_pos[i] + 280, mountain.height[i] + 100, mountain.x_pos[i] + 490, mountain.height[i] + 333);
        quad(mountain.x_pos[i] + 490, mountain.height[i] + 333, mountain.x_pos[i] + 620, mountain.height[i] + 200, mountain.x_pos[i] + 780, mountain.height[i] + 100, mountain.x_pos[i] + 700, mountain.height[i] + 333);
        quad(mountain.x_pos[i] + 490, mountain.height[i] + 333, mountain.x_pos[i] + 450, mountain.height[i] + 200, mountain.x_pos[i] + 380, mountain.height[i] + 80, mountain.x_pos[i] + 316, mountain.height[i] + 140);
        quad(mountain.x_pos[i] + 490, mountain.height[i] + 333, mountain.x_pos[i] + 600, mountain.height[i] + 221, mountain.x_pos[i] + 580, mountain.height[i] + 140, mountain.x_pos[i] + 462, mountain.height[i] + 240);
    }
}

function draw_backMountains() {
    for (let i = 0; i < backMountain.length; i++) {
        fill(80);
        triangle(backMountain[i].x_pos - backMountain[i].height / 2, floorPos_y,
            backMountain[i].x_pos, floorPos_y - backMountain[i].height,
            backMountain[i].x_pos + backMountain[i].height / 2, floorPos_y);
    }
}

// Function to draw trees objects.
function draw_backTrees(){
    for(var i = 0; i < backTree.length; i++) {
        fill(101,51,0);
        rect(74 + backTree[i].x_pos, - backTree[i].height/2 + floorPos_y, 50, backTree[i].height/2);
        fill(0,60,0);
        triangle(backTree[i].x_pos + 25, - backTree[i].height/2 + floorPos_y, backTree[i].x_pos + 100, - backTree[i].height + floorPos_y, backTree[i].x_pos + 175, - backTree[i].height/2 + floorPos_y);
        triangle(backTree[i].x_pos, - backTree[i].height/4 + floorPos_y, backTree[i].x_pos + 100, - backTree[i].height*3/4 + floorPos_y, backTree[i].x_pos + 200, - backTree[i].height/4 + floorPos_y);
    }
}

function drawTrees() {
    // Draw trees ------------------------------------------------------------------------------
    for (var i = 0; i < tree.x_pos.length; i++) {
        fill(90, 40, 20);
        rect(tree.x_pos[i] + 130, tree.height[i] - 10, 4, 60);
        fill(95, 55, 40);
        rect(tree.x_pos[i] + 134, tree.height[i] - 10, 4, 60);
        fill(95, 65, 55);
        rect(tree.x_pos[i] + 138, tree.height[i] - 10, 4, 60);
        fill(15, 80, 10);
        quad(tree.x_pos[i] + 110, tree.height[i] - 10, tree.x_pos[i] + 80, tree.height[i] - 40, tree.x_pos[i] + 200, tree.height[i] - 130, tree.x_pos[i] + 160, tree.height[i] - 10);
        fill(25, 100, 20);
        quad(tree.x_pos[i] + 110, tree.height[i] - 210, tree.x_pos[i] + 80, tree.height[i] - 40, tree.x_pos[i] + 200, tree.height[i] - 130, tree.x_pos[i] + 160, tree.height[i] - 260);
    }
}

// Function to draw houses objects.
function drawBuildings(){
    for(var i = 0; i < buildings.length; i++) {
        fill(30);
        rect(buildings[i].x_pos + buildings[i].height, floorPos_y, buildings[i].width, buildings[i].height - 500);
        fill(180);
        rect(buildings[i].x_pos + 200 + buildings[i].height, floorPos_y, buildings[i].width, buildings[i].height - 500);
        fill(100);
        rect(buildings[i].x_pos - 300 + buildings[i].height, floorPos_y, buildings[i].width, buildings[i].height - 500);
    }
}

function drawHouses() {
    //HOUSES [ITERATION] ------------------------------------------------------------------------------ 
    for (var i = 0; i < houseXs.length; i++) {
        fill(70);
        rect(houseXs[i], floorPos_y - 100, 180, 80);
        fill(21, 25, 0);
        rect(houseXs[i] - 5, floorPos_y - 120, 190, 20);
        rect(houseXs[i] - 5, floorPos_y - 20, 190, 20);
        fill(200, 200, 200, 100);
        rect(houseXs[i] + 15, floorPos_y - 70, 40, 40);
        rect(houseXs[i] + 130, floorPos_y - 70, 40, 40);
        fill(100, 0, 0);
        rect(houseXs[i] + 70, floorPos_y - 80, 50, 60);
    }

    for (var i = 0; i < TALLhouseXs.length; i++) {
        fill(70);
        rect(TALLhouseXs[i], floorPos_y - 200, 180, 180);
        fill(21, 25, 0);
        rect(TALLhouseXs[i] - 5, floorPos_y - 220, 190, 20);
        rect(TALLhouseXs[i] - 5, floorPos_y - 20, 190, 20);
        fill(200, 200, 200, 100);
        rect(TALLhouseXs[i] + 15, floorPos_y - 70, 40, 40);
        rect(TALLhouseXs[i] + 130, floorPos_y - 70, 40, 40);
        rect(TALLhouseXs[i] + 15, floorPos_y - 130, 40, 40);
        rect(TALLhouseXs[i] + 130, floorPos_y - 130, 40, 40);
        rect(TALLhouseXs[i] + 15, floorPos_y - 190, 40, 40);
        rect(TALLhouseXs[i] + 130, floorPos_y - 190, 40, 40);
        fill(0, 0, 80);
        rect(TALLhouseXs[i] + 70, floorPos_y - 80, 50, 60);
    }

    noStroke();
    fill(55);
    rect(house_x - 70, house_y - 25, 150, 170);
    fill(85);
    quad(house_x + 80, house_y - 25, house_x + 80, house_y + 145, house_x + 250, house_y + 50, house_x + 250, house_y - 95);
    //bricks
    fill(70);
    rect(house_x + 5, house_y, 30, 5);
    rect(house_x + 5, house_y, 30, 5);
    rect(house_x - 65, house_y + 10, 5, 5);
    rect(house_x - 45, house_y, 5, 5);
    rect(house_x + 70, house_y + 120, 5, 5);
    rect(house_x + 50, house_y + 130, 5, 5);
    rect(house_x - 65, house_y + 130, 15, 5);
    rect(house_x - 65, house_y, 15, 5);
    rect(house_x - 25, house_y + 90, 15, 5);
    rect(house_x + 15, house_y + 40, 15, 5);
    rect(house_x - 30, house_y + 50, 30, 5);
    fill(85);
    rect(house_x - 25, house_y + 40, 15, 5);
    rect(house_x + 5, house_y + 50, 30, 5);
    rect(house_x - 30, house_y, 30, 5);
    rect(house_x + 70, house_y + 10, 5, 5);
    rect(house_x + 50, house_y, 5, 5);
    rect(house_x + 60, house_y + 130, 15, 5);
    rect(house_x - 65, house_y + 120, 5, 5);
    rect(house_x - 45, house_y + 130, 5, 5);
    rect(house_x - 20, house_y + 110, 15, 5);
    rect(house_x - 30, house_y + 120, 30, 5);
    fill(100);
    rect(house_x - 30, house_y + 100, 30, 5);
    rect(house_x - 10, house_y + 60, 30, 5);
    rect(house_x - 5, house_y + 70, 15, 5);
    rect(house_x + 60, house_y, 15, 5);
    rect(house_x - 10, house_y + 10, 30, 5);
    rect(house_x - 30, house_y + 20, 30, 5);
    rect(house_x + 5, house_y + 20, 30, 5);
    rect(house_x + 5, house_y + 120, 30, 5);
    rect(house_x + 5, house_y + 100, 30, 5);
    rect(house_x + 10, house_y + 110, 15, 5);
    rect(house_x + 10, house_y + 90, 15, 5);
    rect(house_x - 10, house_y + 130, 30, 5);
    //roof
    fill(130, 20, 20);
    quad(house_x + 80, house_y - 10, house_x - 80, house_y - 10, house_x - 50, house_y - 60, house_x + 50, house_y - 60);
    fill(161, 35, 25);
    quad(house_x + 80, house_y - 10, house_x + 260, house_y - 80, house_x + 230, house_y - 120, house_x + 50, house_y - 60);
    fill(165, 60, 60);
    quad(house_x + 230, house_y - 120, house_x + 140, house_y - 120, house_x - 50, house_y - 60, house_x + 50, house_y - 60);
    //door
    fill(50, 20, 0);
    quad(house_x + 150, house_y + 105, house_x + 200, house_y + 79, house_x + 200, house_y - 1, house_x + 150, house_y + 20);
    //knob
    fill(200, 100, 0);
    ellipse(house_x + 180, house_y + 50, 6);
    ellipse(house_x + 175, house_y + 53, 6);
    //window
    fill(255, 255, 255, 150);
    quad(house_x + 100, house_y + 105, house_x + 130, house_y + 90, house_x + 130, house_y + 35, house_x + 100, house_y + 50);
    quad(house_x + 210, house_y + 55, house_x + 240, house_y + 40, house_x + 240, house_y - 5, house_x + 210, house_y + 10);
}

// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(canyon) {
    fill(50, 50, 0);
    rect(canyon.x_pos, floorPos_y + 30, canyon.width, height - floorPos_y);
}

// Function to check character is over a canyon.

function checkCanyon(canyon) {
    if (realPos > canyon.x_pos && realPos < canyon.x_pos + canyon.width) {
        if(!isJumping && !isOnPlatform) {
            isLeft = false;
            isRight = false;
            isJumping = false;
            isFalling = true;
            game_char_y = game_char_y + 3
        }
    }
}

// ----------------------------------
// Pick-up render and check functions
// ----------------------------------

// Function to draw pick-up objects.
function drawPickup(jewel) {
    if (!jewel.isFound) {
        fill(255);
        ellipse(jewel.x_pos + 15, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);
        ellipse(jewel.x_pos + 12, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);
        ellipse(jewel.x_pos + 18, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);

        ellipse(jewel.x_pos - 15, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);
        ellipse(jewel.x_pos - 18, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);
        ellipse(jewel.x_pos - 12, jewel.y_pos + 15, jewel.size - 49, jewel.size - 40);

        //limbs
        noStroke();
        fill(0)
        ellipse(jewel.x_pos + 15, jewel.y_pos, jewel.size - 38, jewel.size - 25);
        fill(30)
        ellipse(jewel.x_pos - 15, jewel.y_pos, jewel.size - 38, jewel.size - 25);
        fill(255);
        ellipse(jewel.x_pos, jewel.y_pos, jewel.size - 25, jewel.size - 20);
        fill(0)
        ellipse(jewel.x_pos - 5, jewel.y_pos + 10, jewel.size - 35, jewel.size - 30);
        fill(30)
        ellipse(jewel.x_pos + 5, jewel.y_pos + 10, jewel.size - 35, jewel.size - 30);

        fill(220)
        ellipse(jewel.x_pos - 5, jewel.y_pos + 10, jewel.size - 43, jewel.size - 38);
        ellipse(jewel.x_pos + 5, jewel.y_pos + 10, jewel.size - 43, jewel.size - 38);

        //ears
        fill(30);
        ellipse(jewel.x_pos - 6, jewel.y_pos - 25, jewel.size - 40);
        fill(255, 182, 193);
        ellipse(jewel.x_pos - 6, jewel.y_pos - 25, jewel.size - 44);
        fill(240);
        ellipse(jewel.x_pos + 6, jewel.y_pos - 25, jewel.size - 40);
        fill(255, 182, 193);
        ellipse(jewel.x_pos + 6, jewel.y_pos - 25, jewel.size - 44);

        //head
        fill(0);
        ellipse(jewel.x_pos, jewel.y_pos - 15, jewel.size - 28, jewel.size - 30);

        //face
        fill(200)
        ellipse(jewel.x_pos, jewel.y_pos - 12, jewel.size - 45, jewel.size - 45);
        fill(255)
        ellipse(jewel.x_pos - 4, jewel.y_pos - 17, jewel.size - 44, jewel.size - 42);
        ellipse(jewel.x_pos + 4, jewel.y_pos - 17, jewel.size - 44, jewel.size - 42);
        fill(0)
        ellipse(jewel.x_pos - 4, jewel.y_pos - 17, jewel.size - 47, jewel.size - 45);
        ellipse(jewel.x_pos + 4, jewel.y_pos - 17, jewel.size - 47, jewel.size - 45);
    }
}
// Function to check character has picked up an item.
function checkPickup(jewel) {
    if (realPos > jewel.x_pos - jewel.size / 2 && realPos < jewel.x_pos + jewel.size / 2 && abs(game_char_y - jewel.y_pos) < 20) {
        if (!jewel.isFound) {
            jewel.isFound = true;
            score += 1;
        }
    }
}

function checkPlayerWon(){
    if(score == jewels.length)
        {
            isWon = true;
            stroke(0);
            strokeWeight(2);
            textSize(60)
            fill(0,255,0);
            text("VICTORY!",400,300)
            text("Press SPACE to advance!",200,365);
            isLeft = false;
            isRight = false;
        }
}

function checkPlayerDied()
{
    if(game_char_y > height) {
      playerDied(); 
    }
}
    
function playerDied()
{
    if(lives > 0) {
        lives -= 1;
        score = 0;
        startGame();
        tokens.length = lives;
    } else if(lives <= 0){
        isLost = true;
    }
}
function drawTokens() {
    for(var i = 0; i<tokens.length; i++) {
        fill(255,255,0);
        ellipse(tokens[i].x_pos, tokens[i].y_pos, 20,20);
    }
}

function nextLevel()
{
    // DO NOT CHANGE THIS FUNCTION!
    console.log('next level');
}